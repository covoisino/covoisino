# simplistic_calculator

A calculator to demonstrate a hopefully simple start for a desktop Flutter app.
